"""
ToxiClean - Streamlit Web Application
========================================
User-friendly interface for the ToxiClean Toxic Speech Neutralizer.

Run with:  streamlit run app/streamlit_app.py
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

import streamlit as st
from modules.pipeline import ToxiCleanPipeline
from modules.word_detector import ToxicWordDetector

# ─── Page Configuration ───────────────────────────────────────────────────────
st.set_page_config(
    page_title="ToxiClean — Toxic Speech Neutralizer",
    page_icon="🧹",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── Custom CSS Styling ───────────────────────────────────────────────────────
st.markdown("""
<style>
    /* Main theme */
    .main { background-color: #0f1117; }
    
    /* Custom header */
    .toxiclean-header {
        background: linear-gradient(135deg, #1a1a2e, #16213e, #0f3460);
        padding: 2rem;
        border-radius: 12px;
        margin-bottom: 2rem;
        border: 1px solid #e94560;
    }
    .toxiclean-title {
        font-size: 2.5rem;
        font-weight: 800;
        color: #e94560;
        margin: 0;
    }
    .toxiclean-subtitle {
        color: #a8b2d8;
        font-size: 1rem;
        margin-top: 0.5rem;
    }
    
    /* Result cards */
    .result-toxic {
        background: linear-gradient(135deg, #2d1b1b, #3d1a1a);
        border-left: 4px solid #e94560;
        border-radius: 8px;
        padding: 1.2rem;
        margin: 1rem 0;
    }
    .result-clean {
        background: linear-gradient(135deg, #1b2d1b, #1a3d1a);
        border-left: 4px solid #39d353;
        border-radius: 8px;
        padding: 1.2rem;
        margin: 1rem 0;
    }
    .result-neutral {
        background: linear-gradient(135deg, #1b1f2d, #1a2040);
        border-left: 4px solid #58a6ff;
        border-radius: 8px;
        padding: 1.2rem;
        margin: 1rem 0;
    }
    
    /* Metric badges */
    .badge-toxic   { background: #e94560; color: white; padding: 3px 10px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; }
    .badge-clean   { background: #39d353; color: black; padding: 3px 10px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; }
    
    /* Word highlight */
    .toxic-word-tag {
        background: #e94560;
        color: white;
        padding: 2px 8px;
        border-radius: 12px;
        margin: 2px;
        display: inline-block;
        font-size: 0.85rem;
    }
    
    /* Info boxes */
    .info-box {
        background: #1a1f36;
        border: 1px solid #2a2f4a;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
    }
    
    /* Arrow */
    .arrow-down {
        text-align: center;
        font-size: 2rem;
        color: #58a6ff;
        margin: 0.5rem 0;
    }
    
    /* Streamlit overrides */
    .stTextArea textarea { 
        font-size: 1rem !important; 
        border-radius: 8px !important;
    }
    .stButton button {
        width: 100%;
        background: linear-gradient(135deg, #e94560, #c73652) !important;
        color: white !important;
        font-size: 1.1rem !important;
        font-weight: bold !important;
        border: none !important;
        border-radius: 8px !important;
        padding: 0.75rem !important;
    }
</style>
""", unsafe_allow_html=True)


# ─── Initialize Pipeline ─────────────────────────────────────────────────────
@st.cache_resource
def load_pipeline():
    """Load and cache the ToxiClean pipeline."""
    return ToxiCleanPipeline()

pipeline = load_pipeline()


# ─── Header ──────────────────────────────────────────────────────────────────
st.markdown("""
<div class="toxiclean-header">
    <p class="toxiclean-title">🧹 ToxiClean</p>
    <p class="toxiclean-subtitle">
        Toxic Speech Neutralizer · NLP-Powered · Real-Time Analysis
    </p>
</div>
""", unsafe_allow_html=True)


# ─── Sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Settings")
    
    strategy = st.selectbox(
        "Neutralization Strategy",
        ["combined", "word_replacement", "rule_based"],
        help="How the system rewrites toxic text"
    )
    
    threshold = st.slider(
        "Detection Sensitivity",
        min_value=0.1,
        max_value=0.9,
        value=0.3,
        step=0.05,
        help="Lower = more sensitive to toxicity"
    )
    
    st.markdown("---")
    st.markdown("## 📖 How It Works")
    
    steps = [
        ("1️⃣", "Text Input", "You type or paste text"),
        ("2️⃣", "Preprocessing", "Clean & normalize text"),
        ("3️⃣", "Detection", "Check for toxicity"),
        ("4️⃣", "Word Analysis", "Find toxic words"),
        ("5️⃣", "Neutralization", "Rewrite toxic content"),
        ("6️⃣", "Output", "Receive clean text"),
    ]
    
    for icon, step, desc in steps:
        st.markdown(f"{icon} **{step}**: {desc}")
    
    st.markdown("---")
    st.markdown("## 🏷️ Toxicity Categories")
    categories = ["💢 Insult", "⚠️ Threat", "😤 Hate Speech", 
                  "🚫 Obscene", "😠 Aggressive"]
    for cat in categories:
        st.markdown(f"• {cat}")


# ─── Main Interface ───────────────────────────────────────────────────────────
col1, col2 = st.columns([1, 1], gap="large")

with col1:
    st.markdown("### 📥 Input Text")
    
    # Example texts
    example_options = {
        "Select an example...": "",
        "🔴 Insult example": "You are such a stupid idiot, completely worthless!",
        "🔴 Threat example": "I will hurt you if you don't shut up and go away!",
        "🔴 Hate speech": "I hate people like you, you're so disgusting and pathetic.",
        "🟢 Clean example": "I disagree with your approach. Let's find a better solution.",
        "🟢 Positive example": "Have a wonderful day! Your work is excellent.",
    }
    
    selected_example = st.selectbox("Try an example:", list(example_options.keys()))
    
    # Text input area
    default_text = example_options.get(selected_example, "")
    user_text = st.text_area(
        "Enter your text here:",
        value=default_text,
        height=150,
        placeholder="Type or paste any text to analyze...",
        help="Enter any text to check for toxic content"
    )
    
    analyze_btn = st.button("🔍 Analyze & Neutralize", type="primary")
    
    # Character count
    if user_text:
        st.caption(f"📊 {len(user_text)} characters · {len(user_text.split())} words")


# ─── Analysis Results ─────────────────────────────────────────────────────────
with col2:
    st.markdown("### 📤 Analysis Results")
    
    if analyze_btn and user_text.strip():
        with st.spinner("🔬 Analyzing text..."):
            # Update pipeline strategy if changed
            pipeline.neutralizer.strategy = strategy
            result = pipeline.analyze(user_text)
        
        # ── Verdict ────────────────────────────────────────────────────
        if result['is_toxic']:
            st.markdown(f"""
            <div class="result-toxic">
                <span class="badge-toxic">🔴 TOXIC CONTENT DETECTED</span>
                <p style="margin: 0.5rem 0 0 0; color: #ffb3b3;">
                    Confidence: {result['confidence']:.0%} · 
                    Intensity: {result['intensity_score']:.0%} · 
                    Toxic words: {result['toxic_count']}
                </p>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown(f"""
            <div class="result-clean">
                <span class="badge-clean">🟢 TEXT IS CLEAN</span>
                <p style="margin: 0.5rem 0 0 0; color: #b3ffb3;">
                    No toxic content detected. Text is safe to use.
                </p>
            </div>
            """, unsafe_allow_html=True)
        
        # ── Toxic Words Found ───────────────────────────────────────────
        if result['toxic_words']:
            st.markdown("**🔍 Toxic Words Detected:**")
            words_html = " ".join([
                f'<span class="toxic-word-tag">{w["word"]} · {w["category"]}</span>'
                for w in result['toxic_words']
            ])
            st.markdown(words_html, unsafe_allow_html=True)
            
            st.markdown("")
        
        # ── Toxicity Types ──────────────────────────────────────────────
        if result['toxicity_types']:
            st.markdown("**⚠️ Toxicity Types:**")
            type_cols = st.columns(len(result['toxicity_types']))
            for i, t in enumerate(result['toxicity_types']):
                with type_cols[i]:
                    st.error(t)
        
        # ── Neutralized Output ──────────────────────────────────────────
        if result['is_toxic']:
            st.markdown("### 🔄 Neutralized Text")
            st.markdown(f"""
            <div class="result-neutral">
                <p style="color: #58a6ff; font-weight: bold; margin: 0 0 0.5rem 0;">
                    ✨ Clean Version:
                </p>
                <p style="color: #e8eaf6; font-size: 1.1rem; margin: 0;">
                    "{result['neutral_text']}"
                </p>
            </div>
            """, unsafe_allow_html=True)
            
            # Changes summary
            if result['changes_made']:
                with st.expander("📝 See what was changed"):
                    for old, new in result['changes_made']:
                        if isinstance(old, str) and isinstance(new, str) and len(old) < 50:
                            st.markdown(f"• `{old}` → `{new}`")
        else:
            st.markdown("""
            <div class="result-clean">
                <p style="color: #39d353; margin: 0;">
                    ✅ Your text is already clean and respectful. No changes needed!
                </p>
            </div>
            """, unsafe_allow_html=True)
    
    elif not user_text.strip() and analyze_btn:
        st.warning("⚠️ Please enter some text to analyze.")
    
    else:
        st.markdown("""
        <div class="info-box">
            <p style="color: #8892b0; text-align: center; margin: 2rem 0;">
                👆 Enter text and click "Analyze & Neutralize"<br>to see the results here.
            </p>
        </div>
        """, unsafe_allow_html=True)


# ─── Batch Analysis Section ───────────────────────────────────────────────────
st.markdown("---")
st.markdown("### 📋 Batch Text Analysis")
st.markdown("Analyze multiple texts at once (one per line):")

batch_text = st.text_area(
    "Enter multiple texts (one per line):",
    height=120,
    placeholder="Text 1\nText 2\nText 3...",
    key="batch_input"
)

if st.button("🔍 Analyze All Texts", key="batch_btn"):
    if batch_text.strip():
        texts = [t.strip() for t in batch_text.split('\n') if t.strip()]
        
        results_data = []
        for text in texts:
            r = pipeline.analyze(text)
            results_data.append({
                'Text': text[:60] + ('...' if len(text) > 60 else ''),
                'Toxic': '🔴 Yes' if r['is_toxic'] else '🟢 No',
                'Confidence': f"{r['confidence']:.0%}",
                'Types': ', '.join(r['toxicity_types']) or 'None',
                'Neutralized': r['neutral_text'][:60] + ('...' if len(r['neutral_text']) > 60 else '')
            })
        
        import pandas as pd
        df = pd.DataFrame(results_data)
        st.dataframe(df, use_container_width=True)
        
        # Summary stats
        toxic_count = sum(1 for r in results_data if '🔴' in r['Toxic'])
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Texts", len(results_data))
        col2.metric("Toxic Texts", toxic_count, delta=f"{toxic_count/len(results_data):.0%}")
        col3.metric("Clean Texts", len(results_data) - toxic_count)


# ─── Footer ───────────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #6272a4; padding: 1rem;">
    <p>🧹 <strong>ToxiClean</strong> · Built with Python, NLTK, scikit-learn & Streamlit</p>
    <p style="font-size: 0.8rem;">
        For educational purposes · Uses rule-based + ML toxicity detection
    </p>
</div>
""", unsafe_allow_html=True)
